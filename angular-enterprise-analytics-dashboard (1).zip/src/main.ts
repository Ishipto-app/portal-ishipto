import 'zone.js';
import '@angular/compiler';
import './index.css';
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app.component.ts';

bootstrapApplication(AppComponent).catch((err) => console.error(err));
